# getgroups
