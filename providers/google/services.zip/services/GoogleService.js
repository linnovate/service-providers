"use strict"
//import Service from 'Service'

var Service = require('./Service.js');
var Authorize = require('./Authorize.js'); 
var google = require('googleapis'); 	//Used to interact with the Google Apps API

class GoogleService extends Service {
   
	  init() {
      var authorize = new Authorize()
      
      this.auth = authorize.getAuth();
    

     // console.log("this.auth ",this.auth) 
	}

  /**
   * Lists the first 100 users in the domain.
   *
   * @param {google.auth.OAuth2} auth An authorized OAuth2 client.
   */

 


   getGroups(auth,callback) {	    
	    var service = google.admin('directory_v1');
	    service.groups.list({
	      auth: auth,
	      customer: 'my_customer',
	      maxResults: 100,
	      orderBy: 'email',
	    },function(err, res){
	    //  console.log(err)
	    //  console.log(res)
	      callback(res);
	    })
  }

	getGroupMembers(auth,callback,groupKey) {
		var service = google.admin('directory_v1');
		var result;
		service.members.list({
		    auth: auth,
		    customer: 'my_customer',
		    maxResults: 100,
		    orderBy: 'email',
		    groupKey: groupKey
		  },function(err, res){
		  //	console.log(err);	   
		  // console.log(res);
		   callback(err,res);		  
		  })
		
		
	}

    


}


var service = new GoogleService('Google');
//service.init();
var authorize = new Authorize()
      
authorize.getAuth(function(auth){

  service.getGroups(auth,function(err,list){
      console.log(list ,err );
   });

}); 
/*service.getGroups(service.auth,function(list){
 console.log(list );

service.getGroupMembers(service.auth,function(list){
	 console.log(list );
	},"bi@linnovate.net");
*/
