"use strict"
class Service { 
  constructor(name) {
    this.name = name;
  }
  init() {}

  getProfileGroups(auth) {
    console.log("getProfileGroups");

  }
 
  removeFromGroup(auth,groupId){}

  getGroupMembers(auth,groupId){}

}

//export Service;
module.exports = Service;




